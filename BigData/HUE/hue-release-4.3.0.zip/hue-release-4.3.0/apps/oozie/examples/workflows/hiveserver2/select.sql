SELECT ${hivevar:fields}
FROM ${hivevar:tablename}
LIMIT ${hivevar:n}
;
